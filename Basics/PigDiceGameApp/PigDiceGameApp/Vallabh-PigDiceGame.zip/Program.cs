﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PigDiceGameApp
{
    class Program
    {
        public class Player
        {
            const int pointsToWin = 20;


            public string PlayerName { get; }
            public int OverallScore { get; set; }

            public bool hasWon() => this.OverallScore >= pointsToWin;

            public Player(string playerName)
            {
                this.PlayerName = playerName;
            }

            public override string ToString()
            {
                return this.PlayerName;
            }

            public class Game
            {
                public Player[] Players { get; }
                public int Turn { get; private set; }

                public Player PlayingPlayer { get; set; }

                public Game(int numberOfPlayers)
                {
                    Players = new Player[numberOfPlayers];
                }

                public void NextTurn()
                {
                    Turn += 1;
                    PlayingPlayer = Players[Turn % Players.Length];
                }

                public string GetScoresTable()
                {
                    string table = "----- Scores -----";

                    foreach (Player player in Players)
                        table += "\n" + player + ": " + player.OverallScore;

                    return table;
                }

                public class Dice
                {
                    private Random random = new Random();

                    public int Roll() => random.Next(6) + 1;
                }
                private static bool GameLoop(Game game)
                {
                    Player player = game.PlayingPlayer;

                    ShowGameStatus(game);

                    if (player.hasWon())
                        return false;

                    Console.Write($"{player}'s turn! Play (no)? ");

                    string playersChoice = Console.ReadLine();

                    if (playersChoice.ToLower() == "no")
                    {
                        Console.WriteLine($"{player} chose to hold!");
                        game.NextTurn();
                        return true;
                    }

                    Dice dice = new Dice();

                    Console.WriteLine($"{player} is rolling the dice!");

                    int number1 = dice.Roll();
                    int number2 = dice.Roll();

                    Console.WriteLine($"{player} got {number1} and {number2}");

                    if (number1 == 1 || number2 == 1)
                    {
                        Console.WriteLine($"Bad luck! {player} lost all points!");
                        player.OverallScore = 0;
                        game.NextTurn();
                        return true;
                    }

                    int scoreWon = number1 + number2;
                    player.OverallScore += scoreWon;

                    Console.WriteLine($"{player} got {scoreWon} score and now has {player.OverallScore}");

                    return true;
                }
                static void Main(string[] args)
                {
                    Console.WriteLine("Welcome to PigDice Game!");
                    Console.Write("Amount of players: ");

                    string inputNumber = Console.ReadLine();
                    int numberOfPlayers = Convert.ToInt32(inputNumber);

                    Game game = new Game(numberOfPlayers);
                    Player[] players = game.Players;

                    game.PlayingPlayer = players[0];

                    while (GameLoop(game)) ;

                    Console.WriteLine(game.PlayingPlayer + " has won!");
                    Console.ReadKey();
                }
            }
        }
    }
}

